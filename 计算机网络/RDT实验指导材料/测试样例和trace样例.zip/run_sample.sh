#./prog_t <msg_num> <loss> <corruption> <snd_time> <trace> <runi>
./prog_t 10 0.0 0.0 100 2 1
# ./GBN 20 0.0 0.0 1000 2 2
# ./GBN 30 0.0 0.3 1000 2 3