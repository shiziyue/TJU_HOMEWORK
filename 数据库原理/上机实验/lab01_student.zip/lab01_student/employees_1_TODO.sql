﻿
-- Create the database first.

CREATE DATABASE employees;

\c employees; -- PostgreSQL

-- 按照实验报告要求编写SQL语句

-- 3
-- 用SQL创建关系表

-- 测试创建的空表
SELECT * FROM employees;
SELECT * FROM departments;
SELECT * FROM dept_emp;
SELECT * FROM dept_manager;
SELECT * FROM titles;
SELECT * FROM salaries;

-- 4


-- 测试导入数据之后的表
SELECT COUNT(*) FROM employees;
SELECT COUNT(*) FROM departments;
SELECT COUNT(*) FROM dept_emp;
SELECT COUNT(*) FROM dept_manager;
SELECT COUNT(*) FROM titles;
SELECT COUNT(*) FROM salaries;

-- 5.1


-- 5.2


-- 5.3


-- 5.4


-- 5.5


-- 5.6


-- 5.7


-- 5.8


-- 5.9


-- 5.10

		
-- 5.11


-- 5.12


-- 5.13


-- 5.14


-- 5.15


-- 5.16


-- 5.17


-- 5.18

